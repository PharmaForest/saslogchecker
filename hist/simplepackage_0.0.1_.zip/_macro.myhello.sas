/*** HELP START ***//*

This is macro to say hello to SAS.

*//*** HELP END ***/

%macro myhello() ;
%put "Hello, SAS world!" ;
%mend ;
