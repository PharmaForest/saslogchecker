Type : Package
Package : SimplePackage
Title : Simple SAS package
Version : 0.0.1
Author : Taro Suzuki(taro.suzuki@simple.com)
Maintainer : Taro Suzuki(taro.suzuki@simple.com)
License : MIT
Encoding : UTF8
Required : "Base SAS Software"
ReqPackages :  

DESCRIPTION START:
## Simple Package ##
Simple is the best!
DESCRIPTION END:
