/*** HELP START ***//*

This is a hello function example.

*//*** HELP END ***/

function hellofun(str $) $ 128;
  return(catx(" ", "Hello", str, "!!"));
endfunc;
