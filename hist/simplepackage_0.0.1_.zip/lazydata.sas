filename P5F7D484 list;

 %put NOTE- ;
 %put NOTE: Data for package SimplePackage, version 0.0.1, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-01-28T10:53:50; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Write %nrstr(%%)helpPackage(SimplePackage) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_;
 length lazyData $ 32767; lazyData = lowcase(symget("lazyData"));
run;
%put NOTE- ;
%put NOTE: Data for package SimplePackage, version 0.0.1, license MIT;
%put NOTE- *** END ***;

/* lazydata.sas end */

