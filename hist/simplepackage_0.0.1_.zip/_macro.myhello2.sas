/*** HELP START ***//*

This is macro to say hello to something.
(e.g. `%myhello2(obj=Taro)`)

*//*** HELP END ***/

%macro myhello2(obj=) ;
%put "Hello, &obj.!" ;
%mend ;
